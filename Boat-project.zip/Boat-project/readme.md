 <h1>OUTPUT</h1>
 <img src = "Boat-1.png">
 <img src = "boat-2.png>
